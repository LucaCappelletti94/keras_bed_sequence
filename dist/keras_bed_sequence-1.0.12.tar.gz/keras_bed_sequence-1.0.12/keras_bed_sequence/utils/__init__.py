from .nucleotides_to_numbers import nucleotides_to_numbers

__all__ = [
    "nucleotides_to_numbers"
]
